export const ignoreDir = ['$recycle', '$trash', '.git', '.sac', '$RECYCLE.BIN', '#recycle', '.pnpm-store']
