// 从字符串中创建webworker线程池
function 从字符串中创建webworker(str){
    return new Worker(str)
}