export const globalKeyboardEvents={
    globalKeyDown:'globalKeyDown'
}