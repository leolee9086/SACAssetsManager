export function rgba数组转字符串(rgba){
    return `rgba(${rgba[0]},${rgba[1]},${rgba[2]},${rgba[3]})`
}
export function rgb数组转字符串(rgb){
    return `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`
}