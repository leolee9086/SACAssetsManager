export const ignoreDir = [
    '$recycle', 
    '$trash', 
    '.git', 
    '.sac', 
    '$RECYCLE.BIN', 
    '#recycle', 
    '.pnpm-store',
    'System Volume Information',
    'Windows/WinSxS',
    'Windows\\WinSxS',
    'temp'
]
