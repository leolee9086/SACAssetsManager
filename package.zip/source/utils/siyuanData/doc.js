function 获取文档图标(文档id){
    
}