import { cc } from "../../utils/componentsLoader.js";

export const commonIcon=cc(['icon'])`<svg><use :xlink:href="'#'+icon"></use></svg>`