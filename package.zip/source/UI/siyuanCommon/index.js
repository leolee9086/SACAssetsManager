/**
 * 菜单相关事件和菜单项定义
 */
import  './menus.js'
/**
 * tab相关事件和tab项定义
 */
import  './tabs.js'

/**
 * shell相关事件和shell项定义
 */
import  './shell.js'