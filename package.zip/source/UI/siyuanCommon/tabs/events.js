export const tabEvents = {
    打开附件面板: 'open-gallery-data',
    打开标签附件页面: 'click-tag-item',
    打开笔记本资源视图: 'click-galleryboxicon',
    打开笔记资源视图: 'click-gallerynoteicon',
}