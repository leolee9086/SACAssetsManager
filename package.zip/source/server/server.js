/**
 * 一个web服务器,用于查看文件服务
 */
import './apiService.js'

/**
 * 开始索引队列
 */
import './indexer.js'
/**
 * 实现自定义的原生拖拽事件
 */
//import './nativeDrag.js'