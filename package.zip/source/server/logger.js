import { 创建日志记录器 } from "../utils/logProxy/index.js";
export const logger = 创建日志记录器('server')