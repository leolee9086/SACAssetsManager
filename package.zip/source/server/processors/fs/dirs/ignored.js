import { ignoreDir } from "../../../../utils/fs/windowsSystemDirs.js";

export {ignoreDir as ignoreDir}