import { databaseRouter } from './router.js'
export {databaseRouter as router}