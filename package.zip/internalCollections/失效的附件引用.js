import { kernelApi } from "../source/asyncModules.js"
export const getnext =()=>{
    const data = kernelApi.sql({stmt:'select * from blocks where '})
}
export const count =()=>{
    
}
export const refresh =()=>{

}
export const sorters =()=>{

}